
import { AuthForm } from '@/components/auth/AuthForm';

const Auth = () => {
  return <AuthForm />;
};

export default Auth;
